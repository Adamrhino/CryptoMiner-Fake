______________________________________________________________________________________

	! You must install Python | https://www.python.org/downloads/ !
________________________________________________________________________________________

1. Open CMD (Command Prompt) 
2. Drag install.bat into CMD
3. Open main.py and ENJOY!!
___________________________________

GitHub: https://www.github.com/adamrhino
________________________________________